echo '
  [01] >> Information Gathering:  -  Collects information from database       ~ /AllHackingTools/.check
  [02] >> Exploitation Tools:  -  selection of tools for operation and hacking ~ /AllHackingTools/Files
  [03] >> Sniffing and Spoofing:  -  Tools for forgery of data and databases  ~ /AllHackingTools/Files
  [04] >> Web Attack Tools:  -  Tools for hacking websites and servers      ~ /AllHackingTools/Files
  [05] >> Cam Hacking Tools:  -  Tools for hacking cams and front camera  ~ /AllHackingTools/Files
  [06] >> Remote Trojan RAT:  -  Utilities for creating RAT virus        ~ /AllHackingTools/Files
      ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  
  [07] >> SQL injection Tool:  -  Tools for creating viruses            ~ /AllHackingTools/Files
  [08] >> SocialMedia Hacking:  -  Tools for hacking social networks    ~ /AllHackingTools/Files
  [09] >> SMS spaming Tools:  -  Utilities for spam and anonymous SMS    ~ /AllHackingTools/.check
  [10] >> Vulnerability Analysis:  -  Systems for vulnerability analysis  ~ /AllHackingTools/Files
  [11] >> DarkSearch Tool:  -  Tools for Secret and Onion search         ~ /AllHackingTools/Files
  [12] >> Phishing And IpHack:  -  Tools for phishing and fake websites ~ /AllHackingTools/Files
  [13] >> Passworld Attack:  -  Utilities for cracking passwords        ~ /AllHackingTools/Files
  [14] >> Wordlist Generator:  -  Tools for Genering Worldlist         ~ /AllHackingTools/Files
  [15] >> XSS Attack Tools:  -  Utilities for Attacking XSS           ~ /AllHackingTools/Files
      ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣⁣  ⁣    ⁣  ⁣⁣  ⁣⁣ 
  [16] >> Other tools:  -  Separate and other tools for hacking      ~ /AllHackingTools/.check
  [17] >> Terminal Panel:  -  Termux control and special features    ~ /AllHackingTools/.check
  [18] >> System Settings:  -  AllHackingTools control and features   ~ /AllHackingTools/.settings
  [19] >> System License:  -  View the license in AllHackingTools     ~ /AllHackingTools/.settings 
  [20] >> Update System:  -  Update system and all tools & menu       ~ /AllHackingTools/.check  
  [21] >> About System:  -  View system information and developer    ~ /AllHackingTools/src 
  [22] >> Exit System:  -  Log out of the AllHackingTools system    ~ /AllHackingTools/  

  [000]————{ DEBUG | DEVELOPER } Misha Korzhik
  [041] >> Edit MainMenu; - edit MainMenu             (WARNING)    ~ /AllHackingTools/     
  [042] >> Clear All Data; - clear unnecessary files  (WARNING)    ~ /AllHackingTools/  
  [043] >> View Directory; - view folder no detail                ~ /AllHackingTools/ 
  [044] >> Reset All Data; - reload date & files                 ~ /AllHackingTools/    
  [045] >> Remove data; - delete some date          (WARNING)    ~ /AllHackingTools/.settings 
  [046] >> View Folder; - detailed view of folders              ~ /AllHackingTools/folder
  [047] >> Off Server; - no description             (WARNING)   ~ /sys/dll                 '|lolcat -p 1.7





