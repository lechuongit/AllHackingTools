echo '
    ┌──────────────────────────────────────────────────────────────┐
    │  	               ┏━┓┏┓ ┏━┓╻ ╻╺┳╸	              │
    │  		       ┣━┫┣┻┓┃ ┃┃ ┃ ┃ 		      │
    │  		       ╹ ╹┗━┛┗━┛┗━┛ ╹ 		      │
    │──────────────────────────────────────────────────────────────│
    │                                                              │
    │ >>   Hi, here you can see my telegram and github there       |
    |       will be questions you will write in telegram.          │
    │                                                              │
    │ >>  Author   :  Misha Korzhik                                │
    │     Github   :  https://github.com/mishakorzik               │
    │     Telegram :  pseudonym @MishaKorzhikTelegram              │
    |     Info     :  Trank for installing AllHackingTools         |
    │                                                              │
    └──────────────────────────────────────────────────────────────┘ 
'|lolcat -a -d 10 -p 1.5 -s 40.0
cd && cd AllHackingTools  
python3 src/Timer.py
python2 src/aboutMenu.py
