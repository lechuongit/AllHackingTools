g="\033[1;32m"
r="\033[1;31m"
b="\033[1;34m"
w="\033[0m"
o="\033[1;33m"

echo -e $w"["$g"INFO"$w"]"$b"Easy passworlds"$w
sleep 0.1
echo 835fU930sgi52fGs
echo 42jdU5BJ62w5283wW
echo 724gIEN62o0wU
echo Yni623nfooa42Gr52H
sleep 0.1
echo Hack724Ge62nfiT28
echo he42I73NdW8IN3J2g
echo jEwbU52nsI8Ns897B2
echo uw42Bwo72KdbW72EqN
sleep 0.1
echo JaoN264o54Hus5nxHSr72
echo 82DsycU4384jsT9365Gs2
echo 834qdQ3W9GeNiI45geiN401
echo 734fsyR38gsbUsbU362Vj
sleep 0.1
echo 82BwoE3NO9E8JfW52B8
echo 8uw253PrOfI839505Vsi
echo 82vTwm73G4529hTEbdiE
echo JeB28KDTw92e5NO92Wr
echo 835fU930sgi52fGs
sleep 0.1
echo 438bs2hwdwG57GWbsi
echo 72abi539VsgiR82U
echo Yni623nfooa42Gr52H
echo Bso7ed62nfi6Vwo8VeU
sleep 0.1
echo hReI7T372BsiywvJ2g
echo jEwbU52vw4I8Ns897B2
echo uw42Bwo72eKdbW72EqN
echo wub564o54HuGsi4HSr72
echo -e $w"["$g"INFO"$w"]"$b"Medium passworlds"$w
echo 82DsycU4384jsT9365Gs282Vqr
sleep 0.2
echo 83w4q24dQ3W9Gwt21JwboYwfc
echo 2iegdjdi422GsjRw835NdoR
echo I8725BdUq2644e72jIv415
echo uwT27529hTEbne538734bD7Bw
echo he27Jey9262WrwH20212ejdO
sleep 0.2
echo 73625dvshRge428Garq4280Hvs
echo 73bsuR623nfoheb573Gr52H73bdhRajI
echo uw638B62nfi6Vwojdv8VeU734bdhh
echo hReI7T3eue6383272BsiyOehd63B
echo RjEHvEwbUjstefe62852vw4I8Ns897B2
echo uw42Bwo72jsgfz538eKdbW72EqN
sleep 0.2
echo w25vUsu264b564o54HuGsi4HSr72
echo 82DsycU43wbbw63ca84jsT9365Gs2
echo yev5385gsuw327Bfjfiai759bfjs
echo dbi13Rwb1512Of2473nIqfBf283i724
echo jsc2730YInQrhO373814Odbod72
sleep 0.2
echo Hsrs25134wjTbwk82359dhKdh50606
echo hd19475eugFauj2783GyBAJAIEU3737
echo dkey628DahwIo2628BTtfGb7252
sleep 0.2
echo -e $w"["$g"INFO"$w"]"$b"Hard passworlds"$w
echo 46hRRwn42eIuab7T3eue6383272BsiyOeishgIehd63B
echo RYw52jEHvEwbUjsteInfoNqfe62852vw4I8Ns8ifn97B2
echo uw28ywhIe42Bwo72Ujwnjsgfz538eUhwbKdbW72EqN
echo 82DsycU43wbbUshbw63ca84jsT936sigTsgb5Gs23
sleep 0.2
echo 82jsb287sjjsgsvTenkd263638odhbTa94Ishb94
echo Ruwbi13Rhsvsgwb1512Of2473nIqfBf2fRsv3i724
echo jsjsVRRc2730YInQrhO3348273814Odbod72dhst
echo hejwyv8352bsjsFr182awbdkdiB8263Vsj736Bd
sleep 0.2
echo 33nshsrrwsjkfodugssqg833542jqjGwboTvw
echo dkey628DahwIo2628BTtfGb7252BsyragUso62I
echo 926EwcTn2sjywfEavI9336oNsiTw1724NdiRbw
cd
cd
cd AllHackingTools
python3 src/Timer1.py
python2 src/aboutMenu.py   
cd
cd AllHackingTools
