apt-get install git
apt-get install python
cd
cd 
cd AllHackingTools
git clone https://github.com/mishakorzik/AdminHack
cd AdminHack
bash setup.sh
cd
cd
cd AllHackingTools
pip install parse
pip2 install parse
pip3 install parse
cd AllHackingTools
git clone https://github.com/m4ll0k/takeover.git
cd takeover
python3 setup.py install
cd
cd AllHackingTools
git clone https://github.com/UltimateHackers/Blazy
cd Blazy
pip install -r requirements.txt
cd 
cd AllHackingTools 
git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git sqlmap-dev
cd
cd AllHackingTools
git clone https://github.com/websploit/websploit.git
cd websploit
python setup.py install
pip2 install scapy
pip3 install scary
cd
cd
cd AllHackingTools
git clone https://github.com/LOoLzeC/SH33LL
cd SH33LL
cd
cd
cd AllHackingTools
git clone https://github.com/s0md3v/sqlmate
cd sqlmate
pip install -r requirements.txt
cd
cd
cd AllHackingTools
git clone https://github.com/ultrasecurity/webkiller.git
cd webkiller
pip3 install -r requirments.txt
cd
cd
cd AllHackingTools
git clone https://github.com/mishakorzik/Ultra-DDos
cd
cd 
cd AllHackingTools
