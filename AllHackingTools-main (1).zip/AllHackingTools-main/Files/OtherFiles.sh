cd
cd
cd AllHackingTools
git clone https://github.com/tuhin1729/ProxyGen.git
cd ProxyGen
pip2 install -r requirements.txt
cd
cd
cd AllHackingTools

