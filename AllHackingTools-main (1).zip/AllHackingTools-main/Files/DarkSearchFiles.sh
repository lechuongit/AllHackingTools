apt-get install git
apt-get install python
apt-get install npm
cd
cd
cd AllHackingTools
git clone https://github.com/josh0xA/darkdump
cd darkdump
python3 -m pip install -r requirements.txt
cd 
cd AllHackingTools
