cd
cd 
cd AllHackingTools
git clone https://github.com/evildevill/instahack
cd 
cd instahack
bash setup
cd
cd
cd AllHackingTools
git clone https://github.com/IAmBlackHacker/Facebook-BruteForce
cd Facebook-BruteForce
python3 -m pip install requests bs4
python3 -m pip install mechanize
cd
cd
cd AllHackingTools
git clone https://github.com/sherlock-project/sherlock.git
cd sherlock
python3 -m pip install -r requirements.txt
cd
cd
cd AllHackingTools
git clone https://github.com/xHak9x/finduser
cd
cd
cd AllHackingTools
git clone https://github.com/mishakorzik/UserFinder
cd
cd
cd AllHackingTools
