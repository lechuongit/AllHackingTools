echo '
  [ 01 ] >> View MySystem
  [ 02 ] >> Google Search
  [ 03 ] >> Battarey Status
  [ 04 ] >> PassGenerator
  [ 05 ] >> Termux Style
  [ 06 ] >> Clear logs
  [ 07 ] >> Termux commands
  [ 08 ] >> Create TermuxBackup
  [ 09 ] >> Restore TermuxBackup
  [ 10 ] >> Reset TermuxPackages
  [ 11 ] >> Termux Banner
  [ 12 ] >> Check Packages
  [ 13 ] >> Add NewExtraKeys
  [ 14 ] >> Exit System
  [ 15 ] >> Back To MainMenu '| lolcat -p 1.9
