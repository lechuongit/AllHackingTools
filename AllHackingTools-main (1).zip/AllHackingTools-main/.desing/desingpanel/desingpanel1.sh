echo '
  [01] >> View MySystem - View my system
  [02] >> Google Search - Open google in terminal
  [03] >> Battarey Status - View my battarey status
  [04] >> PassGenerator - Generate passworld
  [05] >> Termux Style - Terminal castomization
  [06] >> Clear logs - Clear terminal logs
  [07] >> Terminal commands - View terminal commands
  [08] >> Create TerminalBackup - Create terminal backup
  [09] >> Restore TerminalBackup - Restore terminal backup
  [10] >> Reset TerminalPackages - Reset terminal packages
  [11] >> Terminal Banner - Create castom terminal banner
  [12] >> Check Packages - check my packages
  [13] >> Add NewExtraKeys - Add nae extra keys
  [14] >> Exit System - log out AllHackingTools
  [15] >> Back To MainMenu '| lolcat -p 1.7
